#ifndef __SERIAL_SHELL_H__
#define __SERIAL_SHELL_H__



void serial_console_init(char * info);

void shell_iap_command(void * arg);

#endif


