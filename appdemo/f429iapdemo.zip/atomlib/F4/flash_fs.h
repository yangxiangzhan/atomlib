#ifndef FLASH_FS_H_
#define FLASH_FS_H_




void flash_fs_init(void);

extern lfs_t g_flash_lfs;

#endif

